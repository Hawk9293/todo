import React from 'react';
import './Footer.css';

function Footer(){
    return(
        <footer className="footer">
                <p>footer</p>
        </footer>
    )
}

export default Footer;