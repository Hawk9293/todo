import React from 'react';
import './Main.css';

function Main(){
    return(
        <main className="main">
            <div className="tbc">to be continued...</div>
        </main>
    )
}

export default Main;